import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Plus, Users, Settings } from 'lucide-react';
import { adicionarParceiro, parceiros } from '@/data/parceiros';

const Admin = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nome: '',
    imagem: '',
    endereco: '',
    site: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome || !formData.imagem || !formData.endereco) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    try {
      adicionarParceiro({
        nome: formData.nome,
        imagem: formData.imagem,
        endereco: formData.endereco,
        site: formData.site || undefined
      });

      toast({
        title: "Sucesso!",
        description: "Parceiro adicionado com sucesso."
      });

      // Limpar formulário
      setFormData({ nome: '', imagem: '', endereco: '', site: '' });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao adicionar parceiro. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
        <section className="pt-32 pb-20">
          <div className="container-custom">
            {/* Header */}
            <div className="text-center mb-16">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <Settings className="h-12 w-12 text-primary" />
                <h1 className="text-4xl md:text-6xl font-bold text-foreground">
                  Área <span className="text-primary">Administrativa</span>
                </h1>
              </div>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Gerencie os parceiros da Frota Brasil
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Formulário para adicionar parceiro */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Plus className="h-5 w-5" />
                    <span>Adicionar Novo Parceiro</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <Label htmlFor="nome">Nome do Parceiro *</Label>
                      <Input
                        id="nome"
                        type="text"
                        value={formData.nome}
                        onChange={(e) => handleInputChange('nome', e.target.value)}
                        placeholder="Digite o nome do parceiro"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="imagem">URL da Imagem *</Label>
                      <Input
                        id="imagem"
                        type="url"
                        value={formData.imagem}
                        onChange={(e) => handleInputChange('imagem', e.target.value)}
                        placeholder="https://exemplo.com/imagem.jpg"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="endereco">Endereço *</Label>
                      <Textarea
                        id="endereco"
                        value={formData.endereco}
                        onChange={(e) => handleInputChange('endereco', e.target.value)}
                        placeholder="Rua, número, bairro, cidade - UF"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="site">Site (opcional)</Label>
                      <Input
                        id="site"
                        type="url"
                        value={formData.site}
                        onChange={(e) => handleInputChange('site', e.target.value)}
                        placeholder="https://exemplo.com.br"
                      />
                    </div>

                    <Button type="submit" className="w-full">
                      <Plus className="h-4 w-4 mr-2" />
                      Adicionar Parceiro
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Lista de parceiros existentes */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Parceiros Cadastrados ({parceiros.length})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {parceiros.map((parceiro) => (
                      <div key={parceiro.id} className="p-4 bg-muted/20 rounded-lg">
                        <div className="flex items-start space-x-3">
                          <img 
                            src={parceiro.imagem} 
                            alt={parceiro.nome}
                            className="w-16 h-16 object-cover rounded-lg"
                          />
                          <div className="flex-1">
                            <h4 className="font-semibold text-foreground">{parceiro.nome}</h4>
                            <p className="text-sm text-muted-foreground">{parceiro.endereco}</p>
                            {parceiro.site && (
                              <a 
                                href={parceiro.site} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-sm text-primary hover:underline"
                              >
                                {parceiro.site}
                              </a>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {parceiros.length === 0 && (
                      <p className="text-center text-muted-foreground py-8">
                        Nenhum parceiro cadastrado ainda
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Admin;