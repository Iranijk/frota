import { Parceiro } from '../types/parceiro';

export const parceiros: Parceiro[] = [
  {
    id: '1',
    nome: 'Exemplo Parceiro 1',
    imagem: '/placeholder.svg',
    endereco: 'Rua Exemplo, 123 - São Paulo, SP',
    site: 'https://exemplo1.com.br'
  },
  {
    id: '2',
    nome: 'Exemplo Parceiro 2',
    imagem: '/placeholder.svg',
    endereco: 'Av. Principal, 456 - Rio de Janeiro, RJ',
  }
];

// Função para adicionar novo parceiro (será usada na página admin)
export const adicionarParceiro = (novoParceiro: Omit<Parceiro, 'id'>) => {
  const id = (parceiros.length + 1).toString();
  parceiros.push({ ...novoParceiro, id });
};