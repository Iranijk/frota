export interface Parceiro {
  id: string;
  nome: string;
  imagem: string;
  endereco: string;
  site?: string;
}